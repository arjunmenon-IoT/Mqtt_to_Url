package api;

import java.io.IOException;
import java.net.HttpURLConnection;

import java.net.URL;

public class putmethod {
	public static  void main(String[] args) throws IOException {
	 float s431h = 100;
	// String link = String.format("\"http://localhost:8080/Demo/Temp?s431h=55.55&s423=2&s421=888.77&s422=4&s425=5&s431f=6&s405=7&s424=8&s416=9&s432=4&s408=3&hall4nord=32.5\"",);

	 URL url = new URL("http://localhost:8080/Demo/Temp?s431h="+s431h+"&s423=2&s421=3&s422=4&s425=5&s431f=6&s405=7&s424=8&s416=9&s432=4&s408=3&hall4nord=32.5");
	 HttpURLConnection http = (HttpURLConnection)url.openConnection();
	http.setRequestMethod("PUT");
	http.setDoOutput(true);
	http.setRequestProperty("Content-Length", "0");

	System.out.println(http.getResponseCode() + " " + http.getResponseMessage());
	http.disconnect();

}
}
